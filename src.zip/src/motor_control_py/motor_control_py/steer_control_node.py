"""
转向控制节点：订阅目标转角与反馈角度，使用 PID 生成 PWM 控制方向电机。
"""
import pigpio
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64


class PidController:
    """简化位置式 PID（含低通滤波、死区、限幅与斜率限制）。"""
    def __init__(
        self,
        name: str,
        kp: float,
        ki: float,
        kd: float,
        i_max: float,
        deadband: float,
        max_pwm_percent: float,
        max_pwm_step: float,
        filter_alpha: float,
    ):
        self.name = name
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.i_max = i_max
        self.deadband = deadband
        self.max_pwm_percent = max_pwm_percent
        self.max_pwm_step = max_pwm_step
        self.filter_alpha = filter_alpha

        self.target = 0.0
        self.measured = None
        self.filtered = None
        self.integral = 0.0
        self.prev_output = 0.0
        self.prev_filtered = None
        self.last_time = None

    def update_target(self, value: float):
        # 更新目标转角，单位通常为 rad。
        self.target = value

    def update_feedback(self, value: float):
        # 写入反馈并进行一阶低通滤波，抑制噪声
        self.measured = value
        if self.filtered is None:
            self.filtered = value
        else:
            a = self.filter_alpha
            self.filtered = (a * value) + ((1.0 - a) * self.filtered)

    def step(self, now):
        # 执行一次 PID 计算，输出 PWM 百分比
        if self.measured is None or self.filtered is None:
            return None
        if self.last_time is None:
            self.last_time = now
            self.prev_filtered = self.filtered
            return None

        dt = (now - self.last_time).nanoseconds / 1e9
        if dt <= 0.0:
            return None

        # 误差与死区处理
        error = self.target - self.filtered
        if abs(error) < self.deadband:
            error = 0.0

        derivative = 0.0
        if self.prev_filtered is not None:
            derivative = -(self.filtered - self.prev_filtered) / dt

        integral_candidate = self.integral + (error * dt)
        integral_candidate = max(-self.i_max, min(self.i_max, integral_candidate))

        # 位置式 PID 输出并限幅
        raw_output = (self.kp * error) + (self.ki * integral_candidate) + (self.kd * derivative)
        output = max(-self.max_pwm_percent, min(self.max_pwm_percent, raw_output))

        if output == raw_output:
            self.integral = integral_candidate
        else:
            if not ((output >= self.max_pwm_percent and error > 0.0) or
                    (output <= -self.max_pwm_percent and error < 0.0)):
                self.integral = integral_candidate

        # 限制单周期 PWM 变化量，避免突变
        delta = output - self.prev_output
        max_step = self.max_pwm_step
        if delta > max_step:
            output = self.prev_output + max_step
        elif delta < -max_step:
            output = self.prev_output - max_step
        self.prev_output = output
        self.prev_filtered = self.filtered
        self.last_time = now

        return output, error, self.filtered


class SteerControlNode(Node):
    """方向电机控制节点：/target_steer + /steer_position -> PWM + DIR。"""
    def __init__(self):
        super().__init__('steer_control_node')

        # ---------------- 关键参数说明 ----------------
        # pwm_gpio: 方向电机 PWM 输出引脚（BCM 编号）
        self.pwm_gpio = self.declare_parameter('pwm_gpio', 19).value
        # dir_gpio: 方向引脚，用于控制电机正反转
        self.dir_gpio = self.declare_parameter('dir_gpio', 13).value
        # pwm_freq_hz: 硬件 PWM 频率，单位 Hz
        self.pwm_freq = self.declare_parameter('pwm_freq_hz', 100000).value
        # invert_dir: 当电机接线方向相反时，可通过该参数统一翻转方向逻辑
        self.invert_dir = self.declare_parameter('invert_dir', True).value
        # cmd_topic: 目标转向角话题
        self.cmd_topic = self.declare_parameter('cmd_topic', 'target_steer').value
        # feedback_topic: 实际转向角反馈话题
        self.feedback_topic = self.declare_parameter('feedback_topic', 'steer_position').value
        # 方向电机 PID 参数
        self.kp = self.declare_parameter('kp',18000.0).value
        self.ki = self.declare_parameter('ki', 1000.0).value
        self.kd = self.declare_parameter('kd', 0.0).value
        self.i_max = self.declare_parameter('i_max', 5000.0).value
        self.control_hz = self.declare_parameter('control_hz', 50.0).value
        self.max_pwm_percent = self.declare_parameter('max_pwm_percent',100.0).value
        self.filter_alpha = self.declare_parameter('filter_alpha', 0.1).value
        self.deadband = self.declare_parameter('deadband', 0.01).value
        self.max_pwm_step = self.declare_parameter('max_pwm_step', 2.0).value

        # 参数合法性检查，避免错误配置带来危险输出。
        if self.control_hz <= 0.0:
            raise RuntimeError('control_hz must be > 0')
        if self.max_pwm_percent <= 0.0:
            raise RuntimeError('max_pwm_percent must be > 0')
        if not (0.0 < self.filter_alpha <= 1.0):
            raise RuntimeError('filter_alpha must be in (0, 1]')
        if self.deadband < 0.0:
            raise RuntimeError('deadband must be >= 0')
        if self.max_pwm_step <= 0.0:
            raise RuntimeError('max_pwm_step must be > 0')

        # 建立 pigpio 连接，负责硬件 PWM 与方向引脚输出。
        self.pi = pigpio.pi()
        if not self.pi.connected:
            raise RuntimeError('pigpio daemon not running. Run: sudo pigpiod')

        # 初始化方向输出默认电平。
        self.pi.set_mode(self.dir_gpio, pigpio.OUTPUT)
        self.pi.write(self.dir_gpio, 0)

        # 创建转向 PID 控制器。
        self.pid = PidController(
            name='steer',
            kp=self.kp,
            ki=self.ki,
            kd=self.kd,
            i_max=self.i_max,
            deadband=self.deadband,
            max_pwm_percent=self.max_pwm_percent,
            max_pwm_step=self.max_pwm_step,
            filter_alpha=self.filter_alpha,
        )

        # 订阅目标角与反馈角
        self.sub_cmd = self.create_subscription(Float64, self.cmd_topic, self.on_cmd, 10)
        self.sub_fb = self.create_subscription(Float64, self.feedback_topic, self.on_feedback, 10)

        # 控制定时器频率决定 PID 更新周期。
        period = 1.0 / self.control_hz
        self.timer = self.create_timer(period, self.control_step)

    @staticmethod
    def percent_to_duty(percent: int) -> int:
        # pigpio 硬件 PWM 占空比采用 0~1,000,000 标度。
        percent = max(0, min(100, percent))
        return int(percent * 10000)

    def on_cmd(self, msg: Float64):
        self.pid.update_target(msg.data)
        self.get_logger().info(f'target_steer={msg.data:.3f}')

    def on_feedback(self, msg: Float64):
        self.pid.update_feedback(msg.data)

    def control_step(self):
        # 定时控制：PID 计算 -> DIR/PWM 输出
        now = self.get_clock().now()
        result = self.pid.step(now)
        if result is None:
            return

        output, error, filtered = result
        # 输出符号决定方向，绝对值决定 PWM 强度。
        dir_level = 0 if output >= 0.0 else 1
        if self.invert_dir:
            dir_level = 1 - dir_level
        self.pi.write(self.dir_gpio, dir_level)

        # 先换算为百分比，再转换成 pigpio 所需的 duty。
        percent = int(round(abs(output)))
        duty = self.percent_to_duty(percent)
        self.pi.hardware_PWM(self.pwm_gpio, int(self.pwm_freq), duty)

        self.get_logger().info(
            f'steer fb={filtered:.3f} err={error:.3f} out%={output:.1f} duty={duty}'
        )


def main():
    rclpy.init()
    node = SteerControlNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    # 退出前关闭 PWM 和方向输出，避免电机残留驱动。
    node.pi.hardware_PWM(node.pwm_gpio, 0, 0)
    node.pi.write(node.dir_gpio, 0)
    node.pi.stop()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
